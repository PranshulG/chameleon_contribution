//!Add dabatase url here and remove before commit

//!Example: mongodb+srv://<username>:<password>@cluster0.mongodb.net/<database>
module.exports = {
    mongoUrl :''
}