function getHelloMessage(name) {
  return `Hello  ${name}!`;
}
module.exports = { getHelloMessage };
