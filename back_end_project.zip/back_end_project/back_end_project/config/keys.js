//!Add dabatase url here and remove before commit
module.exports = {
    mongoUrl :''
}